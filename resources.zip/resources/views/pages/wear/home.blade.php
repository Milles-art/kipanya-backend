@extends('layouts.wear-design2')

@section('title', 'Kipanya Wear — Quality goods, thoughtfully made')
@section('meta_description', 'Discover curated Kipanya Wear pieces made for everyday living. Clean design, original culture, built to be worn often.')

@section('content')
<div data-d2-home>
  <section class="kp-d2-hero">
    <div class="kp-d2-shell kp-d2-hero-grid">
      <div>
        <span class="kp-d2-kicker"><span class="kp-d2-kicker-dot" aria-hidden="true"></span> New collection available</span>
        <h1>Quality goods,<br><span>thoughtfully</span> made.</h1>
        <p class="kp-d2-hero-copy">Discover curated Kipanya Wear pieces made for everyday living. Clean design, original culture and products built to be worn often.</p>
        <div class="kp-d2-cta-row">
          <a href="{{ route('wear.shop') }}" class="kp-d2-btn kp-d2-btn-dark">
            Shop Collection <i class="ti ti-arrow-right" aria-hidden="true"></i>
          </a>
          <a href="{{ route('wear.about') }}" class="kp-d2-btn kp-d2-btn-light">Our Story</a>
        </div>
      </div>
      <div class="kp-d2-hero-media">
        <div class="col">
          <div class="kp-d2-media tall">
            <img src="https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=600"
                 alt="Kipanya Wear editorial detail" width="600" height="800"
                 fetchpriority="high" decoding="async">
          </div>
          <div class="kp-d2-media square">
            <img src="https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600"
                 alt="Kipanya Wear product detail" width="600" height="600"
                 loading="lazy" decoding="async">
          </div>
        </div>
        <div class="col">
          <div class="kp-d2-media square">
            <img src="https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg?auto=compress&cs=tinysrgb&w=600"
                 alt="Kipanya Wear lifestyle" width="600" height="600"
                 loading="lazy" decoding="async">
          </div>
          <div class="kp-d2-media tall">
            <img src="https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=600"
                 alt="Kipanya Wear collection" width="600" height="800"
                 loading="lazy" decoding="async">
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="kp-d2-features">
    <ul class="kp-d2-shell kp-d2-feature-grid">
      <li class="kp-d2-feature">
        <div class="kp-d2-feature-icon"><i class="ti ti-truck" aria-hidden="true"></i></div>
        <div><strong>Fast Delivery</strong><span>Across Tanzania</span></div>
      </li>
      <li class="kp-d2-feature">
        <div class="kp-d2-feature-icon"><i class="ti ti-refresh" aria-hidden="true"></i></div>
        <div><strong>Easy Returns</strong><span>Simple return process</span></div>
      </li>
      <li class="kp-d2-feature">
        <div class="kp-d2-feature-icon"><i class="ti ti-shield-check" aria-hidden="true"></i></div>
        <div><strong>Secure Payment</strong><span>Protected checkout</span></div>
      </li>
      <li class="kp-d2-feature">
        <div class="kp-d2-feature-icon"><i class="ti ti-headset" aria-hidden="true"></i></div>
        <div><strong>Support</strong><span>We're here to help</span></div>
      </li>
    </ul>
  </section>

  <section class="kp-d2-section" data-d2-home-data>
    <div class="kp-d2-shell">
      <div class="kp-d2-section-head">
        <div>
          <h2>Shop by Category</h2>
          <p>Explore the current Kipanya Wear collection.</p>
        </div>
        <a class="kp-d2-link" href="{{ route('wear.shop') }}">View all <i class="ti ti-arrow-right" aria-hidden="true"></i></a>
      </div>
      <div class="kp-d2-category-grid" data-d2-home-categories data-state="loading">
        <div class="kp-d2-category-card kp-d2-skeleton kp-d2-skeleton-card"></div>
        <div class="kp-d2-category-card kp-d2-skeleton kp-d2-skeleton-card"></div>
        <div class="kp-d2-category-card kp-d2-skeleton kp-d2-skeleton-card"></div>
        <div class="kp-d2-category-card kp-d2-skeleton kp-d2-skeleton-card"></div>
      </div>
      <noscript><p class="kp-d2-noscript-note">Enable JavaScript to browse categories, or <a href="{{ route('wear.shop') }}">go to the full shop</a>.</p></noscript>
    </div>
  </section>

  <section id="featured" class="kp-d2-section kp-d2-section-soft">
    <div class="kp-d2-shell" data-d2-catalog data-d2-home-featured>
      <div class="kp-d2-section-head">
        <div>
          <h2>Featured Products</h2>
          <p>Our most loved pieces from the collection.</p>
        </div>
        <a class="kp-d2-link" href="{{ route('wear.shop') }}">View all <i class="ti ti-arrow-right" aria-hidden="true"></i></a>
      </div>
      <div class="kp-d2-grid" data-d2-featured-grid data-state="loading">
        <div class="kp-d2-skeleton kp-d2-skeleton-lg"></div>
        <div class="kp-d2-skeleton kp-d2-skeleton-lg"></div>
        <div class="kp-d2-skeleton kp-d2-skeleton-lg"></div>
        <div class="kp-d2-skeleton kp-d2-skeleton-lg"></div>
      </div>
      <noscript><p class="kp-d2-noscript-note">Enable JavaScript to see featured products, or <a href="{{ route('wear.shop') }}">go to the full shop</a>.</p></noscript>
    </div>
  </section>
</div>
@endsection
