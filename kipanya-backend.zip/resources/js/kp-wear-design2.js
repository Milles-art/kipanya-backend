(() => {
  const qs = (s, r = document) => r.querySelector(s);
  const qsa = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tzs = n => `TZS ${Number(n || 0).toLocaleString()}`;
  const api = (url, opts = {}) => fetch(url, { ...opts, headers: { Accept:'application/json', 'Content-Type':'application/json', ...(opts.headers||{}) } });

  const nav = qs('[data-kp-design2-nav]');
  if (nav) {
    const onScroll = () => nav.classList.toggle('is-scrolled', window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive:true });
    onScroll();
    const searchBtn = qs('[data-d2-search-toggle]', nav);
    const search = qs('[data-d2-search]', nav);
    const searchInput = qs('[data-d2-search-input]', nav);
    searchBtn?.addEventListener('click', () => { search.hidden = !search.hidden; if (!search.hidden) searchInput?.focus(); });
    qs('[data-d2-menu-toggle]', nav)?.addEventListener('click', () => {
      const menu = qs('[data-d2-mobile-menu]', nav); if (!menu) return;
      menu.hidden = !menu.hidden;
    });
  }

  const toast = (message) => {
    let el = qs('[data-kp-d2-toast]');
    if (!el) { el = document.createElement('div'); el.className='kp-d2-toast'; el.dataset.kpD2Toast=''; document.body.appendChild(el); }
    el.textContent = message; el.classList.add('is-visible'); clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('is-visible'),2200);
  };
  window.KipanyaDesign2 = { toast };

  // Catalog / home data rendering. Backend is the source of truth.
  const catalog = qs('[data-d2-catalog]');
  if (catalog) {
    const grid = qs('[data-d2-product-grid]', catalog);
    const count = qs('[data-d2-count]', catalog);
    const pills = qs('[data-d2-pills]', catalog);
    const status = qs('[data-d2-status]', catalog);
    const sort = qs('[data-d2-sort]', catalog);
    const search = new URLSearchParams(location.search).get('q') || '';
    let categories = [];
    let active = new URLSearchParams(location.search).get('category') || 'all';
    let products = [];

    const card = (p) => {
      const vars = p.variants || [];
      const inStock = vars.filter(v => v.in_stock);
      const out = vars.length > 0 && inStock.length === 0;
      const onSale = Number(p.compare_at_price || 0) > Number(p.price || 0);
      const badge = p.badge ? `<span class="kp-d2-card-badge">${esc(p.badge)}</span>` : '';
      const stock = out ? `<span class="kp-d2-card-stock">Sold Out</span>` : '';
      return `<article class="kp-d2-card">
        <a href="/wear/products/${encodeURIComponent(p.slug)}" class="kp-d2-card-media" aria-label="View ${esc(p.name)}">
          <img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy">
          ${badge}${stock}
        </a>
        <button class="kp-d2-card-action" type="button" data-d2-add data-product-id="${p.id}" aria-label="Add ${esc(p.name)} to bag" ${out?'disabled':''}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8h12l1 12H5L6 8Z"/><path d="M9 8a3 3 0 0 1 6 0"/></svg>
        </button>
        <div class="kp-d2-card-meta">
          <div class="kp-d2-card-meta-top"><a class="kp-d2-card-name" href="/wear/products/${encodeURIComponent(p.slug)}">${esc(p.name)}</a><span class="kp-d2-price">${tzs(p.price)}${onSale?` <s>${tzs(p.compare_at_price)}</s>`:''}</span></div>
          <div class="kp-d2-card-category">${esc(p.category || 'KP Wear')}</div>
        </div>
      </article>`;
    };

    const render = () => {
      let list = [...products];
      if (active !== 'all') list = list.filter(p => String(p.category||'').toLowerCase().replace(/\s+/g,'-') === active);
      const q = search.trim().toLowerCase(); if (q) list = list.filter(p => `${p.name} ${p.description||''} ${p.category||''}`.toLowerCase().includes(q));
      const mode = sort?.value || 'featured';
      if (mode === 'price-low') list.sort((a,b)=>Number(a.price)-Number(b.price));
      if (mode === 'price-high') list.sort((a,b)=>Number(b.price)-Number(a.price));
      if (mode === 'alpha') list.sort((a,b)=>String(a.name).localeCompare(String(b.name)));
      grid.innerHTML = list.length ? list.map(card).join('') : `<div class="kp-d2-empty" style="grid-column:1/-1"><strong>No products found</strong><p>Try another category or search.</p></div>`;
      if (count) count.textContent = `${list.length} ${list.length === 1 ? 'piece' : 'pieces'}`;
      qsa('[data-d2-add]', grid).forEach(btn => btn.addEventListener('click', async e => {
        e.preventDefault(); e.stopPropagation();
        const p = products.find(x => String(x.id) === String(btn.dataset.productId));
        const vars = (p?.variants||[]).filter(v=>v.in_stock);
        if (!vars.length) return;
        if (vars.length > 1) { location.href = `/wear/products/${encodeURIComponent(p.slug)}`; return; }
        btn.disabled = true;
        const r = await window.KipanyaCart?.addItem(vars[0].id, 1);
        btn.disabled = false;
        if (r?.ok) toast(`${p.name} added to bag.`); else toast('Choose a size before adding to bag.');
      }));
    };

    const load = async () => {
      try {
        const [cr, pr] = await Promise.all([
          api('/api/v1/wear/categories'),
          api(`/api/v1/wear/products?per_page=50${search?`&search=${encodeURIComponent(search)}`:''}`)
        ]);
        const cj = await cr.json(), pj = await pr.json();
        categories = cj.data || []; products = pj.data || [];
        if (pills) {
          pills.innerHTML = `<button type="button" class="kp-d2-pill${active==='all'?' is-active':''}" data-cat="all" aria-pressed="${active==='all'}">All</button>` + categories.map(c=>`<button type="button" class="kp-d2-pill${active===c.slug?' is-active':''}" data-cat="${esc(c.slug)}" aria-pressed="${active===c.slug}">${esc(c.name)}</button>`).join('');
          qsa('[data-cat]', pills).forEach(b=>b.addEventListener('click',()=>{ active=b.dataset.cat; const u=new URL(location.href); if(active==='all') u.searchParams.delete('category'); else u.searchParams.set('category',active); history.replaceState({},'',u); qsa('[data-cat]',pills).forEach(x=>{const on=x===b;x.classList.toggle('is-active',on);x.setAttribute('aria-pressed',on)}); render(); }));
        }
        render();
      } catch (e) {
        status.innerHTML = `<div class="kp-d2-error">Could not load products. <button type="button" data-d2-retry>Retry</button></div>`;
        qs('[data-d2-retry]')?.addEventListener('click', load);
      }
    };
    sort?.addEventListener('change', render);
    load();
  }

  // Product detail
  const productRoot = qs('[data-d2-product]');
  if (productRoot) {
    const raw = qs('[data-d2-product-data]', productRoot)?.textContent || '{}';
    let product; try { product = JSON.parse(raw); } catch { product = null; }
    if (!product) return;
    const sizes = product.variants || [];
    const sizeWrap = qs('[data-d2-sizes]', productRoot);
    const colorWrap = qs('[data-d2-colors]', productRoot);
    const qtyEl = qs('[data-d2-qty]', productRoot);
    let qty = 1, selectedSize = '', selectedColor = '';
    const variants = () => sizes.filter(v => (!selectedColor || v.color === selectedColor));
    const renderSizes = () => {
      const names = [...new Set(sizes.map(v=>v.size).filter(Boolean))];
      sizeWrap.innerHTML = names.map(size=>{ const ok=variants().some(v=>v.size===size && v.in_stock); const selected=size===selectedSize; return `<button type="button" class="kp-d2-option-btn${selected?' is-selected':''}" data-size="${esc(size)}" ${ok?'':'disabled'}>${esc(size)}</button>`; }).join('');
      qsa('[data-size]',sizeWrap).forEach(b=>b.addEventListener('click',()=>{selectedSize=b.dataset.size; renderSizes(); updateAddState();}));
    };
    const colors=[...new Set(sizes.map(v=>v.color).filter(Boolean))];
    if (colors.length) { colorWrap.hidden=false; qs('[data-d2-color-list]',colorWrap).innerHTML=colors.map(c=>`<button type="button" class="kp-d2-option-btn" data-color="${esc(c)}">${esc(c)}</button>`).join(''); qsa('[data-color]',colorWrap).forEach(b=>b.addEventListener('click',()=>{selectedColor=b.dataset.color; qsa('[data-color]',colorWrap).forEach(x=>x.classList.toggle('is-selected',x===b)); renderSizes();})); }
    const match = () => variants().find(v=>v.size===selectedSize && v.in_stock);
    const addBtn = qs('[data-d2-add-product]',productRoot);
    const updateAddState = () => { const v=match(); addBtn.disabled=!v; addBtn.textContent=v?'Add to bag':'Select a size'; };
    qs('[data-d2-minus]',productRoot)?.addEventListener('click',()=>{qty=Math.max(1,qty-1);qtyEl.textContent=qty;});
    qs('[data-d2-plus]',productRoot)?.addEventListener('click',()=>{qty=Math.min(99,qty+1);qtyEl.textContent=qty;});
    addBtn?.addEventListener('click',async()=>{const v=match();if(!v)return;addBtn.disabled=true;const r=await window.KipanyaCart?.addItem(v.id,qty);addBtn.disabled=false;if(r?.ok)toast(`${product.name} added to bag.`);else toast('Could not add this item.');});
    renderSizes();
    updateAddState();
  }

  // Cart page
  const cartRoot = qs('[data-d2-cart]');
  if (cartRoot && window.KipanyaCart) {
    const list = qs('[data-d2-cart-list]',cartRoot), subtotal = qs('[data-d2-subtotal]',cartRoot), count = qs('[data-d2-cart-count]',cartRoot);
    const renderCart = async()=>{
      list.innerHTML='<div class="kp-d2-empty">Loading your bag…</div>';
      const r=await window.KipanyaCart.getCart(); const cart=r.data;
      const items=cart?.items||[]; if(!items.length){list.innerHTML='<div class="kp-d2-empty"><strong>Your bag is empty.</strong><p>Browse KP Wear and add something you love.</p><a class="kp-d2-btn kp-d2-btn-dark" href="/wear">Shop Wear</a></div>'; if(subtotal)subtotal.textContent=tzs(0); if(count)count.textContent='0 items'; return;}
      list.innerHTML=items.map(item=>`<div class="kp-d2-cart-item"><a class="kp-d2-cart-thumb" href="/wear/products/${esc(item.product.slug)}"><img src="${esc(item.product.image)}" alt="${esc(item.product.name)}" loading="lazy"></a><div><a class="kp-d2-cart-name" href="/wear/products/${esc(item.product.slug)}">${esc(item.product.name)}</a><div class="kp-d2-cart-meta">${esc(item.variant.size||'')} ${item.variant.color?`· ${esc(item.variant.color)}`:''}</div><div class="kp-d2-cart-price">${tzs(item.unit_price)}</div></div><div class="kp-d2-cart-actions"><div class="kp-d2-qty"><button type="button" data-dec="${item.variant.id}" aria-label="Decrease quantity">−</button><span>${item.quantity}</span><button type="button" data-inc="${item.variant.id}" aria-label="Increase quantity">+</button></div><button class="kp-d2-remove" type="button" data-remove="${item.variant.id}">Remove</button></div></div>`).join('');
      if(subtotal)subtotal.textContent=tzs(cart.subtotal); if(count)count.textContent=`${cart.item_count||0} ${(cart.item_count||0)===1?'item':'items'}`;
      qsa('[data-dec]',list).forEach(b=>b.addEventListener('click',async()=>{const v=await window.KipanyaCart.setItemQuantity(b.dataset.dec,Math.max(1,Number(b.parentElement.querySelector('span').textContent)-1));if(v.ok)renderCart();}));
      qsa('[data-inc]',list).forEach(b=>b.addEventListener('click',async()=>{const v=await window.KipanyaCart.setItemQuantity(b.dataset.inc,Number(b.parentElement.querySelector('span').textContent)+1);if(v.ok)renderCart();else toast(v.raw?.message||'Could not update quantity.');}));
      qsa('[data-remove]',list).forEach(b=>b.addEventListener('click',async()=>{const v=await window.KipanyaCart.removeItem(b.dataset.remove);if(v.ok)renderCart();}));
    };
    renderCart();
  }
})();
