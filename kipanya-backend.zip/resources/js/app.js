import './bootstrap';
import './store';
