<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-md px-4 pb-20 pt-20">
    <div class="mb-8 text-center">
        <p class="text-2xl font-black text-gray-900">KP<span class="text-emerald-600">.</span></p>
        <h1 class="mt-5 text-2xl font-bold tracking-tight text-gray-900">Welcome back</h1>
        <p class="mt-2 text-sm text-gray-500">Sign in using your phone number and verification code.</p>
    </div>

    <form novalidate data-login-form class="space-y-5 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm sm:p-7">
        <div data-primary-step>
            <label class="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-gray-700">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-device-mobile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '15','class' => 'text-gray-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                Phone number
            </label>
            <input name="phone" type="tel" class="field w-full" required placeholder="07XXXXXXXX">
        </div>

        <div data-otp-step class="hidden">
            <label class="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-gray-700">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-shield-lock'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '15','class' => 'text-gray-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                Verification code
            </label>
            <input name="code" class="field w-full text-center text-lg tracking-[.5em]" maxlength="6" inputmode="numeric" placeholder="000000">
            <p class="mt-2 text-xs text-gray-400">We sent a 6-digit code to your phone.</p>
        </div>

        <button class="button-dark flex w-full items-center justify-center gap-2 py-3">
            Continue <span aria-hidden="true">→</span>
        </button>

        <p class="pt-1 text-center text-sm text-gray-500">
            New here?
            <a class="font-medium text-emerald-600 underline-offset-2 hover:underline" href="<?php echo e(route('register')); ?>">Create an account</a>
        </p>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\kipanya-backend\resources\views/pages/login.blade.php ENDPATH**/ ?>