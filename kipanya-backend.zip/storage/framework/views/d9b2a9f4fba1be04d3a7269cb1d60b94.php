<header class="sticky top-0 z-50 border-b border-gray-100 bg-white/95 backdrop-blur">
    <div class="flex h-16 w-full items-center justify-between px-4 sm:px-6 lg:h-20 lg:px-7">

        
        <a href="<?php echo e(route('home')); ?>"
           class="shrink-0 text-2xl font-black tracking-tight">
            KP<span class="text-emerald-600">.</span>
        </a>

        
        <nav class="hidden items-center gap-2 md:flex">
            <a href="<?php echo e(route('home')); ?>"
               class="rounded-xl px-4 py-2.5 text-base font-medium text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950">
                Home
            </a>

            <a href="<?php echo e(route('shop')); ?>"
               class="rounded-xl px-4 py-2.5 text-base font-medium text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950">
                Shop
            </a>

            <a href="<?php echo e(route('collections')); ?>"
               class="rounded-xl px-4 py-2.5 text-base font-medium text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950">
                Collections
            </a>

            <a href="<?php echo e(route('about')); ?>"
               class="rounded-xl px-4 py-2.5 text-base font-medium text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950">
                About
            </a>

            <a href="<?php echo e(route('contact')); ?>"
               class="rounded-xl px-4 py-2.5 text-base font-medium text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950">
                Contact
            </a>
        </nav>

        
        <div class="flex items-center gap-1 md:gap-2">

            
            <button
                data-search-toggle
                type="button"
                class="rounded-xl p-2.5 text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950"
                aria-label="Search">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '20','stroke-width' => '1.8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </button>

            
            <a
                href="<?php echo e(route('wishlist')); ?>"
                class="rounded-xl p-2.5 text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950"
                aria-label="Wishlist">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-heart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '20','stroke-width' => '1.8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </a>

            
            <a
                href="<?php echo e(route('cart')); ?>"
                class="relative rounded-xl p-2.5 text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950"
                aria-label="Cart">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-shopping-bag'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '20','stroke-width' => '1.8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                <span data-cart-count class="badge hidden">0</span>
            </a>

            
            <a
                href="<?php echo e(route('account')); ?>"
                class="rounded-xl p-2.5 text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950"
                aria-label="Account">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '20','stroke-width' => '1.8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </a>

            
            <button
                data-menu-toggle
                type="button"
                class="rounded-xl p-2.5 text-gray-700 transition-all duration-200 hover:bg-gray-100 hover:text-gray-950 md:hidden"
                aria-label="Open menu">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-menu-2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '20','stroke-width' => '1.8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </button>

        </div>
    </div>

    
    <div data-search-panel class="hidden border-t border-gray-100 bg-white px-4 py-4">
        <form action="<?php echo e(route('search')); ?>" class="mx-auto flex max-w-xl gap-2">
            <input
                name="q"
                class="field flex-1"
                placeholder="Search products..."
                autocomplete="off">

            <button type="submit" class="button-dark">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => '18']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                Search
            </button>
        </form>
    </div>

    
    <div data-mobile-menu class="hidden border-t border-gray-100 bg-white px-4 pb-5 pt-3 md:hidden">

        <a
            href="<?php echo e(route('home')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            Home
        </a>

        <a
            href="<?php echo e(route('shop')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            Shop
        </a>

        <a
            href="<?php echo e(route('collections')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            Collections
        </a>

        <a
            href="<?php echo e(route('about')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            About
        </a>

        <a
            href="<?php echo e(route('contact')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            Contact
        </a>

        <a
            href="<?php echo e(route('wishlist')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            Wishlist
        </a>

        <a
            href="<?php echo e(route('account')); ?>"
            class="block rounded-xl px-3 py-3 text-lg font-medium transition hover:bg-gray-100">
            Account
        </a>

    </div>
</header>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-backend\resources\views/components/navbar.blade.php ENDPATH**/ ?>