<svg size="30"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
  class="icon icon-tabler icons-tabler-outline icon-tabler-check"
>
  <path stroke="none" d="M0 0h24v24H0z" fill="none" />
  <path d="M5 12l5 5l10 -10" />
</svg><?php /**PATH C:\Users\DIGITAL STAR\kipanya-backend\storage\framework\views/49f4997d95859bdbe67a2529fce72dd3.blade.php ENDPATH**/ ?>