
<section class="w-full px-4 py-16 sm:px-6 lg:px-8">
    <div class="relative mx-auto max-w-[190rem] overflow-hidden rounded-3xl">

        <img
            src="<?php echo e(asset('assets/wear/editorial/everyday-edit.png')); ?>"
            alt="KP Wear — The Everyday Edit"
            class="block h-[420px] w-full object-cover sm:h-[500px] lg:h-[560px]"
        >

        <div class="absolute inset-0 bg-black/25"></div>

        <div class="absolute inset-0 flex items-center">
            <div class="px-6 text-white sm:px-10 lg:px-14">

                <p class="text-xs font-semibold uppercase tracking-[0.3em]">
                    KP Wear
                </p>

                <h2 class="mt-4 text-4xl font-semibold tracking-tight sm:text-5xl lg:text-6xl">
                    The Everyday Edit
                </h2>

                <p class="mt-4 max-w-md text-base text-white/90 sm:text-lg">
                    Everyday pieces designed to move with you.
                </p>

                <a
                    href="<?php echo e(url('/shop')); ?>"
                    class="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-gray-950 transition hover:bg-gray-100"
                >
                    Explore the Collection

                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabler-arrow-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-4 w-4','stroke-width' => '1.8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </a>

            </div>
        </div>

    </div>
</section>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-backend\resources\views/components/editorial-banner.blade.php ENDPATH**/ ?>