<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('favorites', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('cartoon_id')->constrained()->cascadeOnDelete();
            $table->timestamps();

            $table->unique(['user_id', 'cartoon_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('favorites');
    }
};
